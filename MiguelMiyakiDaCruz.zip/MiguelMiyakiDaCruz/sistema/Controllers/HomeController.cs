using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ClinicaVeterinaria.Models;
using Microsoft.AspNetCore.Authorization;

namespace ClinicaVeterinaria.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();
    }

    [AllowAnonymous]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
